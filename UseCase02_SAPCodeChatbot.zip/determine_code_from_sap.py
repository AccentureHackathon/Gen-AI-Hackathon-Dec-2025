
# -*- coding: utf-8 -*-
"""
SAP ADT Code-/DDIC-Exporter
---------------------------
- Liest ADT-Server-Infos aus config.ini
- Parst XML/TXT mit adtcore:objectReference Zeilen (auch HTML-escaptes Fragment)
- Holt je nach Typ: Source (CLAS), Datentyp (DTEL), Felder (TABL/TTYP)
- Schreibt je Objekt eine gleichnamige .txt in Codeexport/

Autor: (dein Name)
"""
import json
import os
import re
import logging
import configparser
import xml.etree.ElementTree as ET
from typing import Optional, Tuple, List
from urllib.parse import urlparse
import html
import read_table_contents

import requests

# ----------------------------
# Konfiguration & Logging
# ----------------------------


LOG_FORMAT = "%(asctime)s [%(levelname)s] %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

def read_config(config_file: str) -> Tuple[str, str, Optional[str], Optional[str], str]:
    cfg = configparser.ConfigParser()
    with open(config_file, "r", encoding="utf-8") as f:
        cfg.read_file(f)

    base_url = cfg.get("server", "base_url", fallback="").strip()
    username = cfg.get("auth", "username", fallback="").strip()
    password = cfg.get("auth", "password", fallback=None)
    password = (password.strip() or None) if password is not None else None
    cert_path = cfg.get("ssl", "cert_path", fallback=None)
    cert_path = (cert_path.strip() or None) if cert_path is not None else None
    export_dir = cfg.get("output", "export_dir", fallback="Codeexport").strip() or "Codeexport"

    # Validierung der base_url
    def _validate(url: str) -> str:
        if not url:
            raise RuntimeError("In config.ini fehlt [server].base_url")
        if "<" in url or ">" in url:
            raise RuntimeError(f"[server].base_url enthält Platzhalter/ungültige Zeichen: {url}")
        parsed = urlparse(url)
        if parsed.scheme not in ("https", "http") or not parsed.netloc:
            raise RuntimeError(f"[server].base_url ist ungültig: {url}")
        # Wir wollen, dass der Pfad mit /sap/bc/adt endet
        if not parsed.path.rstrip("/").endswith("/sap/bc/adt"):
            raise RuntimeError(f"[server].base_url muss mit '/sap/bc/adt' enden: {url}")
        return url.rstrip("/")

    base_url = _validate(base_url)

    if not username:
        raise RuntimeError("In config.ini fehlt [auth].username")

    return base_url, username, password, cert_path, export_dir


def ensure_export_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


# ----------------------------
# Hilfen für XML-Parsing
# ----------------------------

def wrap_if_fragment(raw_text: str) -> str:
    """
    - Ent-escaped HTML (&lt;...&gt; -> <...>)
    - Wenn nur Fragmente ohne Root vorliegen, wrappe in <objects>
    """
    # 1) HTML-Unescape
    txt = html.unescape(raw_text).strip()

    # 2) Falls kein erkennbares Root-Paar vorhanden ist, aber objectReference vorkommt -> wrap
    if "objectReference" in txt and "<adtcore:objectReference" in txt:
        # Erkennen, ob bereits ein Root-Element vorhanden ist:
        has_root_pair = re.search(r"<[^!?/][^>]*>.*</[^>]+>", txt, flags=re.S)
        if not has_root_pair:
            return f'<objects xmlns:adtcore="http://www.sap.com/adt/core">\n{txt}\n</objects>'

    return txt


def load_object_references(xml_or_txt_file: str) -> List[ET.Element]:
    """
    Lädt die Datei, ent-escaped HTML, wrappen bei Bedarf,
    und gibt eine Liste aller objectReference-Elemente zurück.
    """
    with open(xml_or_txt_file, "r", encoding="utf-8") as f:
        content = f.read()

    prepared = wrap_if_fragment(content)

    try:
        root = ET.fromstring(prepared)
    except ET.ParseError as exc:
        # Debug-Hilfe: temporär korrigierte Datei ausgeben
        tmp_out = xml_or_txt_file + ".prepared.xml"
        try:
            with open(tmp_out, "w", encoding="utf-8") as wf:
                wf.write(prepared)
            logging.error(f"Ungültige XML in '{xml_or_txt_file}': {exc}. "
                          f"Korrigierte Zwischenfassung geschrieben nach '{tmp_out}'")
        except Exception:
            pass
        raise RuntimeError(f"Ungültige XML in '{xml_or_txt_file}': {exc}")

    refs = []
    for elem in root.iter():
        if elem.tag.endswith("objectReference"):
            refs.append(elem)
    return refs


def get_attr(elem: ET.Element, local_name: str) -> Optional[str]:
    """
    Holt ein Attribut unabhängig vom Namespace.
    """
    for k, v in elem.attrib.items():
        if k.endswith(local_name):
            return v
    return None


# ----------------------------
# HTTP & ADT-Zugriff
# ----------------------------

def build_session(username: str, password: Optional[str], cert_path: Optional[str]) -> requests.Session:
    """
    Erstellt eine Requests-Session mit Authentifizierung und SSL-Verify.
    """
    sess = requests.Session()
    if username and password:
        sess.auth = (username, password)
    sess.headers.update({
        "Accept": "application/xml; charset=utf-8"
    })
    if cert_path and os.path.exists(cert_path):
        sess.verify = cert_path   # Server-Zertifikat prüfen gegen bereitgestellte CA/Cert
    else:
        sess.verify = True        # System-CA verwenden
    return sess


def adt_get(session: requests.Session, base_url: str, uri_path: str,
            accepts: List[str], timeout: int = 30) -> requests.Response:
    """
    Führt GET gegen base_url + uri_path aus und versucht mehrere Accept-Header in Reihenfolge.
    """
    last_resp = None
    for acc in accepts:
        headers = dict(session.headers)
        headers["Accept"] = acc
        url = f"{base_url}{uri_path}"
        logging.debug(f"GET {url} (Accept={acc})")
        resp = session.get(url, headers=headers, timeout=timeout)
        last_resp = resp
        if resp.status_code == 200:
            return resp
    return last_resp


# ----------------------------
# Extraktion je Objekttyp
# ----------------------------

def fetch_class_source(session: requests.Session, base_url: str, class_uri: str) -> Optional[str]:
    """
    Holt den Source einer ABAP-Klasse. Versucht /source/main und /source.
    """
    variants = [class_uri + "/source/main", class_uri + "/source"]
    for path in variants:
        resp = adt_get(session, base_url, path, accepts=["text/plain", "application/vnd.sap.adt.abapsource"])
        if resp is not None and resp.status_code == 200 and resp.text:
            return resp.text
    # Fallback: evtl. liefert der ursprüngliche Klassenpfad eine XML mit eingebettetem Source
    resp = adt_get(session, base_url, class_uri, accepts=["application/xml"])
    if resp is not None and resp.status_code == 200 and resp.text:
        try:
            root = ET.fromstring(resp.text)
            src_nodes = (root.findall(".//{*}source")
                         or root.findall(".//{*}mainSource")
                         or root.findall(".//{*}sourceCode"))
            for s in src_nodes:
                txt = s.text or ""
                if txt.strip():
                    return txt
        except ET.ParseError:
            pass
    return None


def extract_data_element_type(xml_text: str) -> str:
    """
    Extrahiert den Datentyp eines Datenelements.
    Mögliche Felder je nach ADT-Version: domainName, builtinType, dataType, length, decimals ...
    """
    root = ET.fromstring(xml_text)
    fields = {
        "domainName": None,
        "builtinType": None,
        "dataType": None,
        "length": None,
        "decimals": None
    }
    for key in list(fields.keys()):
        node = root.find(f".//{{*}}{key}")
        if node is not None and (node.text or "").strip():
            fields[key] = node.text.strip()

    if fields["domainName"]:
        return f"Domain: {fields['domainName']}"
    dtype = fields["builtinType"] or fields["dataType"] or "Unbekannt"
    if fields["length"] and fields["decimals"]:
        return f"{dtype}({fields['length']},{fields['decimals']})"
    elif fields["length"]:
        return f"{dtype}({fields['length']})"
    return dtype


def extract_field_names(xml_text: str) -> List[str]:
    """
    Extrahiert Feldnamen aus Struktur/Tabelle/Tabellentyp-Definition.
    Sucht mehrere mögliche Knotennamen: fieldName, name, ddic:field/ddic:name ...
    """
    root = ET.fromstring(xml_text)
    names = set()

    for tag in ("fieldName", "name"):
        for n in root.findall(f".//{{*}}{tag}"):
            val = (n.text or "").strip()
            if val:
                names.add(val)

    for fld in root.findall(".//{*}field"):
        n = fld.find(".//{*}name")
        if n is not None and (n.text or "").strip():
            names.add(n.text.strip())

    return sorted(names)


# ----------------------------
# Verarbeitung je Objekt
# ----------------------------

def process_object(session: requests.Session,
                   base_url: str,
                   obj_name: str,
                   obj_type: str,
                   obj_uri: str) -> Optional[Tuple[str, str]]:
    """
    Verarbeitet ein einzelnes Objekt und gibt (filename, content) zurück.
    Typen:
      - CLAS/OC -> Source Code
      - DTEL/DE -> Datentyp
      - TABL/*  -> Feldnamen
      - TTYP/DA -> Feldnamen
    Andere Typen werden übersprungen (None).
    """
    safe_name = obj_name.replace("/", "_")
    filename = f"{safe_name}.txt"

    if obj_type.startswith("CLAS"):
        source = fetch_class_source(session, base_url, obj_uri)
        content = source if source else f"[Fehler] Kein Source für {obj_name} abrufbar (URI: {obj_uri})"
        return filename, content

    if obj_type.startswith("DTEL"):
        resp = adt_get(session, base_url, obj_uri, accepts=["application/xml"])
        if resp.status_code == 200 and resp.text:
            dtype = extract_data_element_type(resp.text)
            return filename, f"Datenelement: {obj_name}\nDatentyp: {dtype}\n"
        return filename, f"[Fehler] Datenelement {obj_name} nicht abrufbar: HTTP {resp.status_code}"

    if obj_type.startswith("TABL"):
        #resp = adt_get(session, base_url, obj_uri, accepts=["application/xml"])
        records = read_table_contents.get_table_content(obj_name, rows=10000000)
        return filename, "Table entrys:\n" + "\n" + json.dumps(records) + "\n"
        #if resp.status_code == 200 and resp.text:
        #    fields = extract_field_names(resp.text)
        #    if fields:
        #        return filename, "Feldnamen:\n" + "\n".join(fields) + "\n"
        #    return filename, f"[Hinweis] Keine Feldnamen gefunden für {obj_name}\n"
        #return filename, f"[Fehler] TABL {obj_name} nicht abrufbar: HTTP {resp.status_code}"

    if obj_type.startswith("TTYP"):
        resp = adt_get(session, base_url, obj_uri, accepts=["application/xml"])
        if resp.status_code == 200 and resp.text:
            fields = extract_field_names(resp.text)
            if fields:
                return filename, "Feldnamen (TTYP):\n" + "\n".join(fields) + "\n"
            return filename, f"[Hinweis] Keine Feldnamen gefunden für TTYP {obj_name}\n"
        return filename, f"[Fehler] TTYP {obj_name} nicht abrufbar: HTTP {resp.status_code}"

    # Unsupported: TRAN/T, PINF/KI, NROB/NRO, DEVC/K, SFPF/5F, DOMA/DD usw.
    return None


def save_text(export_dir: str, program_name: str, filename: str, content: str) -> str:
    path = os.path.join(export_dir, filename)
    header = f"### Export durch: {program_name}\n\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(header + content)
    return path


# ----------------------------
# Hauptablauf
# ----------------------------

def main(program_name: str, object_list_file: str, config_file: str) -> None:
    try:
        base_url, username, password, cert_path, export_dir = read_config(config_file)
    except Exception as exc:
        logging.error(str(exc))
        return

    ensure_export_dir(export_dir)
    session = build_session(username, password, cert_path)

    try:
        refs = load_object_references(object_list_file)
    except Exception as exc:
        logging.error(str(exc))
        return

    if not refs:
        logging.warning("No objectReference entries found.")
        return

    count_done = 0
    for ref in refs:
        obj_uri = get_attr(ref, "uri") or ""
        obj_type = get_attr(ref, "type") or ""
        obj_name = get_attr(ref, "name") or ""
        pkg = get_attr(ref, "packageName") or ""

        if not obj_uri or not obj_type or not obj_name:
            logging.warning("Entry without complete attributes found – skipped.")
            continue

        # Falls obj_uri mit '/sap/bc/adt/' beginnt, den Präfix entfernen (Doppelungen vermeiden):
        if obj_uri.startswith("/sap/bc/adt/"):
            obj_uri = obj_uri[len("/sap/bc/adt"):]  # z.B. '/ddic/dataelements/...'

        # Nur die geforderten Typen verarbeiten:
        if not (obj_type.startswith("CLAS") or obj_type.startswith("DTEL")
                or obj_type.startswith("TABL") or obj_type.startswith("TTYP")):
            logging.info(f"Skipping object {obj_name} ({obj_type}) from package {pkg}")
            continue

        logging.info(f"Start work on {obj_name} ({obj_type}) from package {pkg}")
        result = process_object(session, base_url, obj_name, obj_type, obj_uri)
        if result is None:
            continue
        filename, content = result
        path = save_text(export_dir, program_name, filename, content)
        logging.info(f"finished: {path}")
        count_done += 1

    logging.info(f"Finished. {count_done} objects done.")


def export_code(file):
    # Passe Dateinamen bei Bedarf an.
    main("SAPCodeChatbot", file, "config.ini")

export_code("object_overview_sap_response.txt")