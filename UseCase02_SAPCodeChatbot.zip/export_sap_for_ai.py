
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import configparser
import os
import determine_code_from_sap
import get_object_overview_for_salt_and_z_namespace


import sys
import tkinter as tk
from tkinter import ttk

class ConsoleRedirector:
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, message):
        self.text_widget.insert(tk.END, message)
        self.text_widget.see(tk.END)  # Scrollt automatisch nach unten
        self.text_widget.update_idletasks()

    def flush(self):
        pass  # Wird für Kompatibilität benötigt


APP_TITLE = "Config.ini Editor"
CONFIG_FILE = "config.ini"

DEFAULTS = {
    "auth": {
        "username": "FSH",
        "password": ""
    },
    "ssl": {
        "cert_path": r"C:/Users/felix.schiesser/PycharmProjects/SAPCodeChatbot/swudevssgs4as.salt-solutoins.de.crt"
    },
    "server": {
        "base_url": "https://swudevssgs4as.salt-solutions.de:44300/sap/bc/adt"
    },
    "output": {
        "export_dir": "Codeexport",
        "overview_filename": "object_overview_sap_response.txt"  # Neues Feld
    },
    "extra": {
        "namespaces": ""  # multiple namespaces allowed
    }
}


class ConfigEditor(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=10)
        self.master = master
        self.config = configparser.ConfigParser()

        # Variablen
        self.var_username = tk.StringVar(value=DEFAULTS["auth"]["username"])
        self.var_password = tk.StringVar(value=DEFAULTS["auth"]["password"])
        self.var_cert_path = tk.StringVar(value=DEFAULTS["ssl"]["cert_path"])
        self.var_base_url = tk.StringVar(value=DEFAULTS["server"]["base_url"])
        self.var_export_dir = tk.StringVar(value=DEFAULTS["output"]["export_dir"])
        self.var_overview_filename = tk.StringVar(value=DEFAULTS["output"]["overview_filename"])
        self.var_namespaces = tk.StringVar(value=DEFAULTS["extra"]["namespaces"])

        # Autosave bei Änderungen
        for var in [self.var_username, self.var_password, self.var_cert_path,
                    self.var_base_url, self.var_export_dir, self.var_overview_filename, self.var_namespaces]:
            var.trace_add("write", lambda *args: self.save_config())

        self._build_ui()
        self.load_config()

    def _build_ui(self):
        row = 0
        ttk.Label(self, text="Username:").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.var_username, width=50).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        ttk.Label(self, text="Password:").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.var_password, show="•", width=50).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        ttk.Label(self, text="Certificate Path:").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.var_cert_path, width=50).grid(row=row, column=1, sticky="ew", pady=4)
        ttk.Button(self, text="Browse…", command=self.browse_cert).grid(row=row, column=2, padx=4)
        row += 1

        ttk.Label(self, text="Base URL:").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.var_base_url, width=50).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        ttk.Label(self, text="Export Directory:").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.var_export_dir, width=50).grid(row=row, column=1, sticky="ew", pady=4)
        ttk.Button(self, text="Browse…", command=self.browse_export).grid(row=row, column=2, padx=4)
        row += 1

        ttk.Label(self, text="Overview Filename:").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.var_overview_filename, width=50).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        ttk.Label(self, text="Namespaces:").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self.var_namespaces, width=50).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        # Start Button
        btn_frame = ttk.Frame(self)
        btn_frame.grid(row=row, column=0, columnspan=3, pady=10, sticky="e")
        ttk.Button(btn_frame, text="Start", command=self.on_start).pack(side="right", padx=5)

        self.pack(fill="both", expand=True)

    def browse_cert(self):
        path = filedialog.askopenfilename(title="Select Certificate File")
        if path:
            self.var_cert_path.set(path)

    def browse_export(self):
        path = filedialog.askdirectory(title="Select Export Directory")
        if path:
            self.var_export_dir.set(path)

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            self.config.read(CONFIG_FILE)
            for section in self.config.sections():
                for key in self.config[section]:
                    var_name = f"var_{key}"
                    if hasattr(self, var_name):
                        getattr(self, var_name).set(self.config[section][key])

    def save_config(self):
        self.config.clear()
        self.config["auth"] = {"username": self.var_username.get(), "password": self.var_password.get()}
        self.config["ssl"] = {"cert_path": self.var_cert_path.get()}
        self.config["server"] = {"base_url": self.var_base_url.get()}
        self.config["output"] = {
            "export_dir": self.var_export_dir.get(),
            "overview_filename": self.var_overview_filename.get()
        }
        self.config["extra"] = {"namespaces": self.var_namespaces.get()}
        with open(CONFIG_FILE, "w") as f:
            self.config.write(f)

    def on_start(self):
        # Übersicht erzeugen
        get_object_overview_for_salt_and_z_namespace.get_object_overview(
            self.var_overview_filename.get(), self.var_namespaces.get()
        )
        messagebox.showinfo("Start", f"Object overview file '{self.var_overview_filename.get()}' created.")

        # Popup für Coding-Export
        answer = messagebox.askyesno("Export Coding", "Do you also want to export the coding of the classes?")
        if answer:
            messagebox.showinfo("Action", "Export coding selected. This may take a few minutes.")
            determine_code_from_sap.export_code(self.var_overview_filename.get())
        else:
            messagebox.showinfo("Action", f"Export coding skipped. You can upload '{self.var_overview_filename.get()}' to your chatbot.")


if __name__ == "__main__":
    root = tk.Tk()
    root.title(APP_TITLE)
    root.geometry("700x400")
    app = ConfigEditor(root)
    root.mainloop()
