
# -*- coding: utf-8 -*-
"""
SAP ADT Data Preview Client – generische, CSRF-fähige Version
-------------------------------------------------------------
- Lädt Zugangsdaten aus config.ini
- Optional: Holt DDL (GET /ddic/tables/.../source/main) und extrahiert Spalten
- Führt Data Preview (POST /datapreview/ddic) mit CSRF-Token durch
- Resiliente Fallbacks für Alias/Struktur-Felder (flache Sicht)
- Parst XML in DataFrame (oder Liste von Dicts)
"""

import configparser
import os
import uuid
import getpass
from typing import List, Dict, Optional, Union
from urllib.parse import quote

import requests
import xml.etree.ElementTree as ET
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Namespace der ADT DataPreview-Antwort
NS = {'dp': 'http://www.sap.com/adt/dataPreview'}

# ADT-kompatibler User-Agent (aus deiner Vorgabe)
USER_AGENT_ECLIPSE = 'Eclipse/4.36.0.v20250528-1830 (win32; x86_64; Java 23) ADT/3.52.0 (devedition)'


# ----------------------------
# Config & Utilities
# ----------------------------

def load_config(config_path: str) -> Dict[str, Dict[str, str]]:
    cp = configparser.ConfigParser()
    read_files = cp.read(config_path, encoding='utf-8')
    if not read_files:
        raise FileNotFoundError(f"config.ini nicht gefunden: {config_path}")

    for section in ['auth', 'ssl', 'server']:
        if section not in cp:
            raise ValueError(f"Section [{section}] fehlt in {config_path}")

    return {
        'auth': {
            'username': cp['auth'].get('username', '').strip(),
            'password': cp['auth'].get('password', '').strip(),
        },
        'ssl': {
            'cert_path': cp['ssl'].get('cert_path', '').strip(),
        },
        'server': {
            'base_url': cp['server'].get('base_url', '').strip().rstrip('/'),
        },
        'output': {
            'export_dir': cp['output'].get('export_dir', '').strip(),
            'overview_filename': cp['output'].get('overview_filename', '').strip(),
        },
        'extra': {
            'namespaces': cp['extra'].get('namespaces', '').strip(),
        }
    }


def ensure_password(auth_cfg: Dict[str, str]) -> None:
    if auth_cfg.get('password'):
        return
    env_pwd = os.getenv('SAP_ADT_PASSWORD', '')
    if env_pwd:
        auth_cfg['password'] = env_pwd
    else:
        auth_cfg['password'] = getpass.getpass(
            f"Passwort für SAP-ADT-User '{auth_cfg.get('username', '')}': "
        )


def create_session_with_retry() -> requests.Session:
    """Session mit moderater Retry-Strategie (für transiente Fehler)"""
    session = requests.Session()
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        status=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST", "HEAD"]
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('https://', adapter)
    session.mount('http://', adapter)
    return session


def build_headers(accept: str, content_type: Optional[str] = None) -> Dict[str, str]:
    headers = {
        'Accept': accept,
        'Cache-Control': 'no-cache',
        'User-Agent': USER_AGENT_ECLIPSE,
        'X-sap-adt-profiling': 'server-time',
        'sap-adt-connection-id': uuid.uuid4().hex,
        'sap-adt-request-id': uuid.uuid4().hex,
    }
    if content_type:
        headers['Content-Type'] = content_type
    return headers


# ----------------------------
# DDL (optional)
# ----------------------------

def get_table_definition(base_url: str,
                         ddic_entity_name: str,
                         auth: tuple,
                         verify: Union[str, bool],
                         headers: Dict[str, str]) -> str:
    """GET /sap/bc/adt/ddic/tables/<encoded>/source/main"""
    path_entity = ddic_entity_name.lower()
    encoded = quote(path_entity, safe='')
    url = f"{base_url}/ddic/tables/{encoded}/source/main"
    resp = requests.get(url, auth=auth, headers=headers, verify=verify, timeout=(5, 30))
    resp.raise_for_status()
    return resp.text


def parse_abap_ddl_to_columns(ddl_text: str) -> List[str]:
    """
    Einfache DDL-Parser-Heuristik:
    - ignoriert Annotationen (@...) und 'include ...'
    - extrahiert Namen links vom ':'; entfernt 'key ' Präfix und ';'
    - gibt Spaltennamen UPPER zurück
    """
    cols: List[str] = []
    for raw in ddl_text.splitlines():
        line = raw.strip()
        if not line or line.startswith('@') or line.startswith('define table'):
            continue
        if line.lower().startswith('include '):
            continue
        if ':' in line:
            left = line.split(':', 1)[0].strip()
            if left.lower().startswith('key '):
                left = left[4:].strip()
            left = left.rstrip(';')
            if left:
                cols.append(left.upper())
    # Deduplikation
    return list(dict.fromkeys(cols))


# ----------------------------
# CSRF-Token & Data Preview
# ----------------------------

def get_csrf_token(session: requests.Session,
                   base_url: str,
                   auth: tuple,
                   verify,
                   extra_headers: dict = None) -> str:
    """CSRF-Token holen (primär /discovery, Fallback HEAD auf /datapreview/ddic)"""
    url = f"{base_url}/discovery"
    headers = {
        'Accept': 'application/xml',
        'X-CSRF-Token': 'Fetch',
        'Cache-Control': 'no-cache',
        'User-Agent': USER_AGENT_ECLIPSE,
        'X-sap-adt-profiling': 'server-time',
        'sap-adt-connection-id': uuid.uuid4().hex,
        'sap-adt-request-id': uuid.uuid4().hex,
    }
    if extra_headers:
        headers.update(extra_headers)

    resp = session.get(url, auth=auth, headers=headers, verify=verify, timeout=(5, 30))
    token = resp.headers.get('X-CSRF-Token')

    if not token:
        head_url = f"{base_url}/datapreview/ddic"
        head_headers = headers.copy()
        head_headers['Accept'] = '*/*'
        head_headers['X-CSRF-Token'] = 'Fetch'
        resp2 = session.head(head_url, auth=auth, headers=head_headers, verify=verify, timeout=(5, 30))
        token = resp2.headers.get('X-CSRF-Token')

    if not token:
        raise RuntimeError("Kein CSRF-Token erhalten. Prüfe SICF/CSRF-Konfiguration und ADT-Services.")
    return token


def _post_datapreview(session: requests.Session,
                      base_url: str,
                      ddic_entity_name: str,
                      rows: int,
                      select_sql: str,
                      auth: tuple,
                      verify,
                      token: str) -> requests.Response:
    """Einzelner POST mit vorhandenem CSRF-Token (ohne hartcodierte Tabellenanteile)"""
    url = f"{base_url}/datapreview/ddic"
    params = {
        'rowNumber': str(rows),
        # **nur einmal** korrekt kodieren (inkl. '/'):
        'ddicEntityName': quote(ddic_entity_name.upper(), safe=''),
    }
    headers = {
        'Accept': 'application/xml, application/vnd.sap.adt.datapreview.table.v1+xml',
        'Content-Type': 'text/plain',
        'X-CSRF-Token': token,
        'Cache-Control': 'no-cache',
        'User-Agent': USER_AGENT_ECLIPSE,
        'X-sap-adt-profiling': 'server-time',
        'sap-adt-connection-id': uuid.uuid4().hex,
        'sap-adt-request-id': uuid.uuid4().hex,
    }
    return session.post(url, params=params, data=select_sql,
                        auth=auth, headers=headers, verify=verify, timeout=(5, 60))


def fetch_datapreview_resilient(session: requests.Session,
                                base_url: str,
                                ddic_entity_name: str,
                                rows: int,
                                columns: List[str],
                                auth: tuple,
                                verify) -> str:
    """
    Resiliente Strategie für beliebige Tabellen:
    1) SELECT * FROM <TAB>
    2) SELECT TAB~COL,... FROM <TAB>
    3) SELECT COL,... FROM <TAB>
    4) Spalten-Probing: jede Spalte einzeln (plain dann qualified), baue gültige Liste
    - bei 403: Token erneuern und einmal wiederholen
    """
    token = get_csrf_token(session, base_url, auth, verify)
    entity = ddic_entity_name.upper()

    def attempt_select(select_cols: str) -> requests.Response:
        select_sql = f"SELECT {select_cols} FROM {entity}"
        resp = _post_datapreview(session, base_url, ddic_entity_name, rows, select_sql, auth, verify, token)
        if resp.status_code == 403:
            # Token erneuern + einmaliger Retry
            token_retry = get_csrf_token(session, base_url, auth, verify)
            resp = _post_datapreview(session, base_url, ddic_entity_name, rows, select_sql, auth, verify, token_retry)
        return resp

    # 1) SELECT *
    resp = attempt_select('*')
    if resp.status_code == 200:
        return resp.text

    # 2) Qualifizierte Spalten (TAB~COL)
    qualified = ', '.join(f"{entity}~{c}" for c in columns)
    resp2 = attempt_select(qualified)
    if resp2.status_code == 200:
        return resp2.text

    # 3) Unqualifizierte Spalten (COL)
    plain = ', '.join(columns)
    resp3 = attempt_select(plain)
    if resp3.status_code == 200:
        return resp3.text

    # 4) Spalten-Probing (flache gültige Spalten automatisch finden)
    valid_cols: List[str] = []
    for c in columns:
        # erst unqualifiziert probieren
        r_plain = attempt_select(c)
        if r_plain.status_code == 200:
            valid_cols.append(c)
            continue
        # dann qualifiziert versuchen
        r_qual = attempt_select(f"{entity}~{c}")
        if r_qual.status_code == 200:
            valid_cols.append(c)

    if valid_cols:
        resp_final = attempt_select(', '.join(valid_cols))
        if resp_final.status_code == 200:
            return resp_final.text

    # Wenn alles scheitert: den letzten Fehler hochwerfen (zeigt Server-Message)
    # bevor wir raisen, resp3/resp2/resp enthalten meist den aussagekräftigen Text:
    last = resp3 if resp3 is not None else (resp2 if resp2 is not None else resp)
    last.raise_for_status()
    # (raise_for_status hebt die Server-Meldung an die Oberfläche)


# ----------------------------
# Parser: XML → Zeilen
# ----------------------------

def parse_datapreview_xml(xml_text: str,
                          return_df: bool = True) -> Union[List[Dict[str, Optional[str]]], "pandas.DataFrame"]:
    root = ET.fromstring(xml_text)

    col_names: List[str] = []
    col_values: List[List[Optional[str]]] = []

    for col in root.findall('dp:columns', NS):
        meta = col.find('dp:metadata', NS)
        meta_name = meta.attrib.get(f"{{{NS['dp']}}}name") or meta.attrib.get('name') or 'UNKNOWN_COL'
        col_names.append(meta_name)
        values = [node.text for node in col.findall('dp:dataSet/dp:data', NS)]
        col_values.append(values)

    n_rows = max((len(vals) for vals in col_values), default=0)

    rows: List[Dict[str, Optional[str]]] = []
    for i in range(n_rows):
        r: Dict[str, Optional[str]] = {}
        for j, cname in enumerate(col_names):
            vlist = col_values[j]
            r[cname] = vlist[i] if i < len(vlist) else None
        rows.append(r)

    if return_df:
        try:
            import pandas as pd
            return pd.DataFrame(rows)
        except Exception:
            pass
    return rows


# ----------------------------
# High-Level: generisch für beliebige Tabellen
# ----------------------------

def get_table_data(config_path: str,
                   ddic_entity_name: str,
                   rows: int = 1000,
                   use_ddl: bool = True,
                   select_columns: Optional[List[str]] = None,
                   return_df: bool = True,
                   export_to_csv: bool = False,
                   csv_filename: Optional[str] = None):
    """
    Generische Hauptfunktion (keine Hardcodings):
    - Lädt Config + Auth
    - Spalten: DDL oder vorgegebene
    - Data Preview mit resilienten Fallbacks (SELECT*, qualifiziert, unqualifiziert, Probing)
    - Rückgabe: DataFrame oder Liste
    - Optional: CSV-Export ins config.output.export_dir
    """
    cfg = load_config(config_path)
    ensure_password(cfg['auth'])

    base_url = cfg['server']['base_url']
    cert_path = cfg['ssl'].get('cert_path') or True  # True=System-CA; Pfad=Custom CA
    auth = (cfg['auth']['username'], cfg['auth']['password'])

    session = create_session_with_retry()

    # Spalten ermitteln
    if select_columns and len(select_columns) > 0:
        columns = [c.upper() for c in select_columns]
    elif use_ddl:
        ddl_headers = build_headers(accept='text/plain')
        ddl_text = get_table_definition(base_url, ddic_entity_name, auth, cert_path, ddl_headers)
        columns = parse_abap_ddl_to_columns(ddl_text)
        if not columns:
            # Wenn keine Spalten aus der DDL erkannt wurden, versuchen wir später SELECT *
            columns = []
    else:
        # ohne DDL und ohne select_columns → wir probieren direkt SELECT *
        columns = []

    # Resilienter Data Preview
    if not columns:
        # Keine Spaltenliste? → starte mit SELECT * (und ggf. Probing scheitert mangels Liste)
        # Für Probing bräuchten wir eine Liste; in vielen Fällen reicht SELECT * ohnehin.
        token = get_csrf_token(session, base_url, auth, cert_path)
        select_sql = f"SELECT * FROM {ddic_entity_name.upper()}"
        resp = _post_datapreview(session, base_url, ddic_entity_name, rows, select_sql, auth, cert_path, token)
        if resp.status_code == 403:
            token = get_csrf_token(session, base_url, auth, cert_path)
            resp = _post_datapreview(session, base_url, ddic_entity_name, rows, select_sql, auth, cert_path, token)
        resp.raise_for_status()
        xml_text = resp.text
    else:
        # mit Spaltenliste die resilienten Fallbacks ausführen
        xml_text = fetch_datapreview_resilient(session, base_url, ddic_entity_name, rows, columns, auth, cert_path)

    # XML → Daten
    data = parse_datapreview_xml(xml_text, return_df=return_df)

    # Optional CSV-Export
    if export_to_csv:
        try:
            import pandas as pd
            if isinstance(data, pd.DataFrame):
                export_dir = cfg['output'].get('export_dir') or '.'
                os.makedirs(export_dir, exist_ok=True)
                if not csv_filename:
                    base_name = ddic_entity_name.strip('/').replace('/', '_').lower()
                    csv_filename = f"{base_name}_preview.csv"
                out_csv = os.path.join(export_dir, csv_filename)
                data.to_csv(out_csv, index=False, encoding='utf-8')
                print(f"CSV exportiert: {out_csv}")
        except Exception as e:
            print(f"CSV-Export fehlgeschlagen: {e}")

    return data


# ----------------------------
# Einfacher Einstiegspunkt
# ----------------------------

def get_table_content(tabname: str,
                      rows: int = 1000,
                      return_df: bool = True):
    """
    Aufruf mit beliebigem DDIC-Tabellennamen (z.B. '/SALT/XSI_SHPCON' oder '/SALT/XSI_PART')
    """
    CONFIG = 'config.ini'
    try:
        df_or_rows = get_table_data(
            CONFIG,
            ddic_entity_name=tabname,  # roh übergeben (nicht vor-kodieren!)
            rows=rows,
            use_ddl=True,              # DDL lesen und versuchen, Spalten zu extrahieren
            return_df=return_df,
            export_to_csv=False
        )
        return df_or_rows
    except Exception as e:
        # Syntaktisch vollständige Fehlerbehandlung
        print(f"Fehler: {e}")
        # Optional für Debug:
        # import traceback; traceback.print_exc()
        return None


# Beispiel: (kannst du beliebig anpassen oder entfernen)
#if __name__ == '__main__':
 #   print(get_table_content('/SALT/XSI_SHPCON', rows=1000))
  #  print(get_table_content('/SALT/XSI_PART', rows=1000))
   # print(get_table_content('/AUK/CUSTNODE', rows=1000))