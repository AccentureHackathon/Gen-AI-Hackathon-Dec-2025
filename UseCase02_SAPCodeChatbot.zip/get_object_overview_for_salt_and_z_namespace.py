
import json
import xmltodict
import requests
import xml.dom.minidom
from requests.auth import HTTPBasicAuth
from configparser import ConfigParser
import os

# Sprachwahl: 'de' oder 'en'
LANG = "en"

# i18n Dictionary
MESSAGES = {
    "de": {
        "missing_auth": "Benutzername oder Passwort fehlt. Bitte in config.ini oder als Umgebungsvariable SAP_PASSWORD setzen.",
        "config_not_found": "Config-Datei nicht gefunden.",
        "request_error": "Fehler beim Abrufen der Daten:",
        "ssl_error": "SSL-Fehler: Bitte prüfe den Zertifikatspfad in config.ini.",
        "success": "✅ Erfolg! Dateien gespeichert:",
        "xml_path": "- XML-Datei:",
        "json_path": "- JSON-Datei:"
    },
    "en": {
        "missing_auth": "Username or password missing. Please set in config.ini or as environment variable SAP_PASSWORD.",
        "config_not_found": "Config file not found.",
        "request_error": "Error fetching data:",
        "ssl_error": "SSL error: Please check certificate path in config.ini.",
        "success": "✅ Success! Files saved:",
        "xml_path": "- XML file:",
        "json_path": "- JSON file:"
    }
}

# Config laden
config = ConfigParser()
if not config.read("config.ini", encoding="utf-8"):
    raise FileNotFoundError(MESSAGES[LANG]["config_not_found"])

# Authentifizierung aus Config oder ENV
username = config.get("auth", "username", fallback=None)
password = os.getenv("SAP_PASSWORD") or config.get("auth", "password", fallback=None)

# Zertifikatspfad
cert_path = config.get("ssl", "cert_path", fallback=None)
base_url = config.get("server", "base_url", fallback="").strip()
base_url = f"{base_url}/repository/informationsystem/search"

def get_objects(query):
    # Basis-URL und Parameter

    params = {
        "operation": "quickSearch",
        "query": query,
        "maxResults": 1000000000
    }

    # Header
    headers = {
        "Accept": "application/xml",
        "Content-Type": "application/xml",
        "X-sap-adt-sessiontype": "stateful"
    }

    try:
        response = requests.get(
            base_url,
            params=params,
            headers=headers,
            auth=HTTPBasicAuth(username, password),
            verify=cert_path if cert_path else True,
            timeout=60
        )
    except requests.exceptions.SSLError:
        raise SystemExit(MESSAGES[LANG]["ssl_error"])
    except requests.exceptions.RequestException as e:
        raise SystemExit(f"{MESSAGES[LANG]['request_error']} {e}")

    if response.status_code == 200:
        return response.text
    else:
        print(f"{MESSAGES[LANG]['request_error']} HTTP {response.status_code}\n{response.text}")

# Funktion zum Bereinigen der Keys
def clean_keys(obj):
    if isinstance(obj, dict):
        new_dict = {}
        for k, v in obj.items():
            new_key = k.replace("@adtcore:", "").replace("@", "")
            new_dict[new_key] = clean_keys(v)
        return new_dict
    elif isinstance(obj, list):
        return [clean_keys(item) for item in obj]
    else:
        return obj


import html
import re

def save_as_xml_file(filename, content):


    # Harte Ersetzung: alle problematischen Steuerzeichen durch Leerzeichen ersetzen
    # Bereich: 0x00–0x1F (außer Tab, CR, LF)
    for ch in ['&quot;', '&lt;', '&amp;', '&gt;']:
        content = content.replace(ch, ' ')  # ersetzt durch Leerzeichen

    # XML formatieren
    dom = xml.dom.minidom.parseString(content)
    pretty_xml = dom.toprettyxml(indent="  ")

    # XML speichern
    xml_file_path = filename
    with open(xml_file_path, "w", encoding="utf-8") as xml_file:
        xml_file.write(pretty_xml)


def convert_xml_to_json_file(filename, content):
    # XML in Dict umwandeln und bereinigen
    xml_dict = xmltodict.parse(content)
    cleaned_dict = clean_keys(xml_dict)

    # JSON speichern
    json_file_path = filename
    with open(json_file_path, "w", encoding="utf-8") as json_file:
        json.dump(cleaned_dict, json_file, indent=4, ensure_ascii=False)

def get_object_overview(filename, namespace):
    save_as_xml_file(filename, get_objects(namespace))
